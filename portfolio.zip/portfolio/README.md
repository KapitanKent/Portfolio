# Portfolio (React + Vite)

A one-page software engineer portfolio with an interactive animated background.

## Run it (PowerShell)

```powershell
cd $HOME\Desktop\portfolio
npm.cmd install      # first time only — downloads React + Vite into node_modules
npm.cmd run dev      # starts a local server, open the http://localhost:5173 link it prints
```

Edits you save in VS Code show up in the browser instantly.

Other commands:

- `npm.cmd run build`: creates an optimized production version in `dist/`
- `npm.cmd run preview`: serves the `dist/` build locally to check it

Requires Node.js 18 or newer (`node -v` to check).

## Where to edit things

| What | File |
|---|---|
| **Your content** (name, bio, hobbies, languages, projects, playlist, contacts) | `src/data.js` |
| Colors / layout / animations (CSS) | `src/styles/global.css` (theme colors at the top in `:root`) |
| Icons (add your own) | `src/components/Icon.jsx` |
| Each page section | `src/components/Hero.jsx`, `About.jsx`, `Hobbies.jsx`, `Languages.jsx`, `Projects.jsx`, `Playlist.jsx`, `Contact.jsx` |
| Animated background, mouse effects | `src/components/Background.jsx`, `src/hooks/useInteractions.js` |
| Page order | `src/App.jsx` |

**Your photo:** put it in `public/` (for example `public/me.jpg`), then set `photo: "/me.jpg"` in `src/data.js`.
Project screenshots work the same way (`image: "/taskflow.png"`).

## Notes

- The music player and contact form are **mockups**: no audio plays and no message is sent.
- Animations turn off automatically for visitors who enable "reduce motion" in their OS.

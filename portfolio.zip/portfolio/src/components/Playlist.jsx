import { useEffect, useState } from "react";
import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import Icon from "./Icon";
import { playlist } from "../data";

/*
  A MOCK player — it doesn't play real audio. It simulates progress so the
  section feels alive. To use a real Spotify player instead, replace the
  left card with Spotify's embed <iframe> (Spotify → Share → Embed playlist).
*/

const BARS = 28;
const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

export default function Playlist() {
  const { tracks } = playlist;
  const [cur, setCur] = useState(0);
  const [pos, setPos] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [bars, setBars] = useState(() => Array(BARS).fill(3));

  const track = tracks[cur];
  const go = (n) => { setCur((n + tracks.length) % tracks.length); setPos(0); };

  // Advance one "second" while playing
  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setPos((p) => p + 1), 1000);
    return () => clearInterval(t);
  }, [playing]);

  // Jump to the next track when the current one ends
  useEffect(() => {
    if (pos >= track.seconds) go(cur + 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pos]);

  // Fake audio visualizer
  useEffect(() => {
    if (!playing) { setBars(Array(BARS).fill(3)); return; }
    const t = setInterval(() => {
      const now = Date.now();
      setBars(Array.from({ length: BARS }, (_, k) => 4 + Math.abs(Math.sin(now / 300 + k * 0.7)) * 18 + Math.random() * 12));
    }, 120);
    return () => clearInterval(t);
  }, [playing]);

  const seek = (e) => {
    const b = e.currentTarget.getBoundingClientRect();
    setPos(Math.floor(((e.clientX - b.left) / b.width) * track.seconds));
  };

  return (
    <section id="playlist">
      <div className="container">
        <SectionHeader tag="05. now playing" title="Favorite Spotify Playlist" />
        <div className="spotify">
          <Reveal className={`card player${playing ? " playing" : ""}`}>
            <div className="cover">
              <Icon name="vinyl" className="vinyl" />
              <span>[ playlist<br />cover ]</span>
            </div>
            <h3>{playlist.name}</h3>
            <small>{track.title} · {track.artist}</small>
            <div className="viz">
              {bars.map((h, k) => <i key={k} style={{ height: `${h}px` }} />)}
            </div>
            <div className="progress" onClick={seek}>
              <div style={{ width: `${(pos / track.seconds) * 100}%` }} />
            </div>
            <div className="time"><span>{fmt(pos)}</span><span>{fmt(track.seconds)}</span></div>
            <div className="controls">
              <button aria-label="Previous" onClick={() => go(cur - 1)}><Icon name="prev" /></button>
              <button className="play magnetic" aria-label={playing ? "Pause" : "Play"} onClick={() => setPlaying(!playing)}>
                <Icon name={playing ? "pause" : "play"} />
              </button>
              <button aria-label="Next" onClick={() => go(cur + 1)}><Icon name="next" /></button>
            </div>
          </Reveal>

          <Reveal className={`card tracks${playing ? " playing" : ""}`} delay={0.08}>
            {tracks.map((t, i) => (
              <div key={i} className={`track${i === cur ? " active" : ""}`} onClick={() => { go(i); setPlaying(true); }}>
                <span className="n">
                  <span className="num">{String(i + 1).padStart(2, "0")}</span>
                  <span className="mini-eq"><i /><i /><i /></span>
                </span>
                <div><b>{t.title}</b><small>{t.artist}</small></div>
                <span className="d">{fmt(t.seconds)}</span>
              </div>
            ))}
            <div style={{ padding: "0 22px 10px" }}>
              <a className="open-spotify" href={playlist.url} target="_blank" rel="noopener noreferrer">
                Open full playlist on Spotify <Icon name="external" className="oi" />
              </a>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

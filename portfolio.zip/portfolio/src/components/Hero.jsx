import { useEffect, useRef, useState } from "react";
import Icon from "./Icon";
import { profile } from "../data";
import { prefersReducedMotion } from "../hooks/useReducedMotion";

// Floating code symbols. depth = how far they move with the mouse (negative = opposite way)
const GLYPHS = [
  { t: "{ }", top: "14%", left: "8%", size: "2.6rem", depth: 30, dur: "7s" },
  { t: "</>", top: "70%", left: "12%", size: "2rem", depth: -24, dur: "6s", blue: true },
  { t: "=>", top: "22%", left: "52%", size: "1.6rem", depth: 18, dur: "8s" },
  { t: "( )", top: "80%", left: "48%", size: "2.2rem", depth: -36, dur: "5s", blue: true },
  { t: "#", top: "10%", left: "88%", size: "1.8rem", depth: 40, dur: "6.5s" },
  { t: "[ ]", top: "62%", left: "90%", size: "2.4rem", depth: -20, dur: "7.5s", blue: true },
  { t: "&&", top: "45%", left: "3%", size: "1.4rem", depth: 26, dur: "9s" },
  { t: ";", top: "38%", left: "96%", size: "1.4rem", depth: -30, dur: "6s", blue: true },
];

/** Types and deletes each role in turn. */
function Typewriter({ words }) {
  const [text, setText] = useState("");
  useEffect(() => {
    let w = 0, i = 0, deleting = false, t;
    const tick = () => {
      const word = words[w];
      setText(word.slice(0, i));
      if (!deleting && i < word.length) i++;
      else if (deleting && i > 0) i--;
      else if (!deleting) { deleting = true; t = setTimeout(tick, 1500); return; }
      else { deleting = false; w = (w + 1) % words.length; }
      t = setTimeout(tick, deleting ? 40 : 85);
    };
    tick();
    return () => clearTimeout(t);
  }, [words]);
  return <span>{text}</span>;
}

/** Name split into letters: they animate in, and hop when hovered. */
function AnimatedName({ text }) {
  let i = 0;
  const hop = (e) => {
    const el = e.currentTarget;
    el.classList.remove("hop");
    void el.offsetWidth; // restart the animation
    el.classList.add("hop");
  };
  return (
    <h1>
      {text.split(" ").map((word, wi, arr) => (
        <span key={wi}>
          <span className="word">
            {[...word].map((ch) => (
              <span key={i} className="ch" style={{ "--i": i++ }} onMouseEnter={hop}>
                {ch}
              </span>
            ))}
          </span>
          {wi < arr.length - 1 ? " " : ""}
        </span>
      ))}
    </h1>
  );
}

export default function Hero() {
  const photoRef = useRef(null);
  const glyphRefs = useRef([]);

  // Parallax: photo + glyphs move with the mouse
  const onMouseMove = (e) => {
    if (prefersReducedMotion()) return;
    const cx = e.clientX / innerWidth - 0.5;
    const cy = e.clientY / innerHeight - 0.5;
    if (photoRef.current) {
      photoRef.current.style.transform = `translate(${cx * -18}px, ${cy * -18}px) rotateX(${cy * 6}deg) rotateY(${cx * -6}deg)`;
    }
    glyphRefs.current.forEach((g, k) => {
      if (g) g.style.transform = `translate(${cx * GLYPHS[k].depth}px, ${cy * GLYPHS[k].depth}px)`;
    });
  };

  return (
    <section id="home" onMouseMove={onMouseMove}>
      <div className="glyphs" aria-hidden="true">
        {GLYPHS.map((g, k) => (
          <div
            key={k}
            ref={(el) => (glyphRefs.current[k] = el)}
            className={`glyph${g.blue ? " b" : ""}`}
            style={{ top: g.top, left: g.left, "--s": g.size }}
          >
            <span style={{ "--t": g.dur }}>{g.t}</span>
          </div>
        ))}
      </div>

      <div className="container hero">
        <div>
          <div className="hello">// hello world, I'm</div>
          <AnimatedName text={profile.name} />
          <div className="typed">
            <span className="p">&gt;</span> <Typewriter words={profile.roles} />
          </div>
          <p className="lead">{profile.intro}</p>
          <div className="btns">
            <a href="#projects" className="btn primary magnetic">
              View my work <Icon name="arrowRight" className="bi" />
            </a>
            <a href="#contact" className="btn ghost magnetic">
              Get in touch <Icon name="chat" className="bi" />
            </a>
          </div>
        </div>

        <div className="photo-wrap">
          <div className="parallax" ref={photoRef}>
            <div className="orbit r1" />
            <div className="orbit r2" />
            <div className="orbit r3"><i /><i /></div>
            <div className="photo">
              {profile.photo ? (
                <img src={profile.photo} alt={profile.name} />
              ) : (
                <>
                  <Icon name="user" className="avatar" />
                  [ your photo here ]
                </>
              )}
            </div>
            {profile.openToWork && (
              <div className="badge b1"><span className="dot" />open to work</div>
            )}
            <div className="badge b2"><Icon name="pin" className="mini" />{profile.location}</div>
          </div>
        </div>
      </div>

      <a href="#about" className="scroll-cue">
        scroll<span className="mouse" />
      </a>
    </section>
  );
}

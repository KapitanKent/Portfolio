import { useEffect, useRef } from "react";
import { prefersReducedMotion, hasFinePointer } from "../hooks/useReducedMotion";

/*
  Everything behind the page content:
   1. Glowing colour blobs that drift, one follows the mouse
   2. A dot grid (canvas) that bends + lights up near the cursor,
      a particle trail, and click shockwaves
   3. A cursor ring that grows over clickable things
*/

const GAP = 30;   // space between grid dots (px)
const LENS = 170; // radius of the mouse "lens" (px)

// Read the theme colours from CSS so the canvas matches if you change them
const cssRGB = (name, fallback) =>
  getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;

export default function Background() {
  const canvasRef = useRef(null);
  const followRef = useRef(null);
  const ringRef = useRef(null);
  const blobsRef = useRef([]);

  useEffect(() => {
    const reduce = prefersReducedMotion();
    const fine = hasFinePointer();
    const accent = cssRGB("--accent-rgb", "61,220,151");
    const accent2 = cssRGB("--accent-2-rgb", "90,176,255");

    const cv = canvasRef.current;
    const ctx = cv.getContext("2d");
    const mouse = { x: -9999, y: -9999, sx: -9999, sy: -9999 };
    const trail = [];
    const waves = [];
    let W = 0, H = 0, raf;
    let fx = innerWidth / 2, fy = innerHeight / 2; // glow-follow position
    let rx = 0, ry = 0;                             // cursor-ring position

    const resize = () => {
      const dpr = Math.min(devicePixelRatio || 1, 2);
      W = innerWidth; H = innerHeight;
      cv.width = W * dpr; cv.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();

    const onMove = (e) => {
      mouse.x = e.clientX; mouse.y = e.clientY;
      followRef.current?.classList.add("on");
      ringRef.current?.classList.remove("hidden");
      if (!reduce) {
        for (let k = 0; k < 2; k++) {
          trail.push({ x: e.clientX, y: e.clientY, vx: (Math.random() - 0.5) * 1.2, vy: (Math.random() - 0.5) * 1.2 - 0.3, life: 1, blue: Math.random() < 0.35 });
        }
      }
    };
    const onLeave = () => { mouse.x = mouse.y = -9999; ringRef.current?.classList.add("hidden"); };
    const onClick = (e) => { if (!reduce) waves.push({ x: e.clientX, y: e.clientY, r: 0, a: 1 }); };
    const onDown = () => ringRef.current?.classList.add("down");
    const onUp = () => ringRef.current?.classList.remove("down");
    const onOver = (e) => ringRef.current?.classList.toggle("hover", !!e.target.closest?.("a, button, .card, .chip, input, textarea, .ch"));

    const drawField = () => {
      ctx.clearRect(0, 0, W, H);
      mouse.sx += (mouse.x - mouse.sx) * 0.18;
      mouse.sy += (mouse.y - mouse.sy) * 0.18;
      const off = -(scrollY * 0.25) % GAP;
      for (const w of waves) { w.r += 9; w.a -= 0.012; }
      while (waves.length && waves[0].a <= 0) waves.shift();

      // Dot grid
      for (let y = off - GAP; y < H + GAP; y += GAP) {
        for (let x = GAP / 2; x < W + GAP; x += GAP) {
          let px = x, py = y, glow = 0;
          const dx = x - mouse.sx, dy = y - mouse.sy, d = Math.hypot(dx, dy);
          if (d < LENS && d > 0) {
            const f = 1 - d / LENS;
            px += (dx / d) * f * f * 26; py += (dy / d) * f * f * 26;
            glow = f;
          }
          for (const w of waves) {
            const wd = Math.hypot(x - w.x, y - w.y), band = Math.abs(wd - w.r);
            if (band < 40) {
              const f = (1 - band / 40) * w.a;
              px += ((x - w.x) / (wd || 1)) * f * 12; py += ((y - w.y) / (wd || 1)) * f * 12;
              glow = Math.max(glow, f);
            }
          }
          if (glow > 0) {
            ctx.fillStyle = `rgba(${accent},${0.12 + glow * 0.85})`;
            ctx.beginPath(); ctx.arc(px, py, 1 + glow * 1.8, 0, Math.PI * 2); ctx.fill();
          } else {
            ctx.fillStyle = "rgba(127,142,163,.13)";
            ctx.fillRect(px - 0.75, py - 0.75, 1.5, 1.5);
          }
        }
      }

      // Lines from the cursor to nearby dots
      if (mouse.x > -999) {
        ctx.lineWidth = 1;
        for (let x = Math.floor((mouse.sx - 90) / GAP) * GAP + GAP / 2; x < mouse.sx + 90; x += GAP) {
          for (let y = Math.floor((mouse.sy - off - 90) / GAP) * GAP + off; y < mouse.sy + 90; y += GAP) {
            const d = Math.hypot(x - mouse.sx, y - mouse.sy);
            if (d < 90) {
              ctx.strokeStyle = `rgba(${accent2},${(1 - d / 90) * 0.35})`;
              ctx.beginPath(); ctx.moveTo(mouse.sx, mouse.sy); ctx.lineTo(x, y); ctx.stroke();
            }
          }
        }
      }

      // Particle trail
      for (let k = trail.length - 1; k >= 0; k--) {
        const p = trail[k];
        p.x += p.vx; p.y += p.vy; p.life -= 0.025;
        if (p.life <= 0) { trail.splice(k, 1); continue; }
        ctx.fillStyle = `rgba(${p.blue ? accent2 : accent},${p.life * 0.8})`;
        ctx.beginPath(); ctx.arc(p.x, p.y, 2.4 * p.life, 0, Math.PI * 2); ctx.fill();
      }
      if (trail.length > 160) trail.splice(0, trail.length - 160);

      // Shockwave rings
      for (const w of waves) {
        ctx.strokeStyle = `rgba(${accent},${w.a * 0.35})`; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(w.x, w.y, w.r, 0, Math.PI * 2); ctx.stroke();
      }
    };

    const loop = () => {
      drawField();
      // Glow blob that follows the mouse (slow and smooth)
      if (mouse.x > -999) { fx += (mouse.x - fx) * 0.05; fy += (mouse.y - fy) * 0.05; }
      if (followRef.current) followRef.current.style.transform = `translate(${fx}px, ${fy}px)`;
      // Other blobs move at different speeds while scrolling (parallax)
      blobsRef.current.forEach((b) => b && (b.style.transform = `translateY(${-scrollY * b.dataset.p}px)`));
      // Cursor ring
      if (fine && ringRef.current) {
        rx += (mouse.x - rx) * 0.2; ry += (mouse.y - ry) * 0.2;
        ringRef.current.style.transform = `translate(${rx}px, ${ry}px)`;
      }
      raf = requestAnimationFrame(loop);
    };

    addEventListener("resize", resize);
    addEventListener("mousemove", onMove);
    addEventListener("click", onClick);
    addEventListener("mousedown", onDown);
    addEventListener("mouseup", onUp);
    document.addEventListener("mouseover", onOver);
    document.documentElement.addEventListener("mouseleave", onLeave);
    if (!reduce) loop();

    return () => {
      cancelAnimationFrame(raf);
      removeEventListener("resize", resize);
      removeEventListener("mousemove", onMove);
      removeEventListener("click", onClick);
      removeEventListener("mousedown", onDown);
      removeEventListener("mouseup", onUp);
      document.removeEventListener("mouseover", onOver);
      document.documentElement.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  const blobs = [
    { cls: "w1", p: 0.12 },
    { cls: "w2", p: -0.08 },
    { cls: "w3", p: 0.2 },
    { cls: "w4", p: -0.15 },
  ];

  return (
    <>
      <div id="glow" aria-hidden="true">
        {blobs.map((b, i) => (
          <div key={b.cls} className={`bw ${b.cls}`} data-p={b.p} ref={(el) => (blobsRef.current[i] = el)}>
            <div className="blob" />
          </div>
        ))}
        <div className="follow" ref={followRef} />
      </div>
      <canvas id="field" ref={canvasRef} aria-hidden="true" />
      <div id="ring" className="hidden" ref={ringRef} />
    </>
  );
}

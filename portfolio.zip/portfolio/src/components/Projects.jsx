import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import CountUp from "./CountUp";
import Icon from "./Icon";
import { projects } from "../data";

// Placeholder "app window" lines (width %, colour) shown when there's no screenshot
const FAKE_LINES = [
  [["40", "a"], ["85"], ["70"], ["55", "b"], ["78"]],
  [["50", "b"], ["72"], ["35", "a"], ["88"], ["60"]],
  [["65"], ["45", "a"], ["80"], ["58"], ["30", "b"]],
];

function repoName(url) {
  return url.replace(/^https?:\/\/(www\.)?github\.com\//, "");
}

export default function Projects() {
  return (
    <section id="projects">
      <div className="container">
        <SectionHeader tag="04. things I've built" title="Projects" />
        <div className="proj-grid">
          {projects.map((p, i) => (
            <Reveal key={p.title} className="card project tilt" delay={i * 0.08}>
              {({ inView }) => (
                <>
                  <div className="thumb">
                    {p.image ? (
                      <img src={p.image} alt={`${p.title} screenshot`} />
                    ) : (
                      <>
                        <div className="win">
                          <div className="dots"><i /><i /><i /></div>
                          {FAKE_LINES[i % FAKE_LINES.length].map(([w, c], k) => (
                            <div key={k} className={`l${c ? " " + c : ""}`} style={{ width: `${w}%` }} />
                          ))}
                        </div>
                        <span className="label">[ screenshot ]</span>
                      </>
                    )}
                  </div>
                  <div className="body">
                    <h3>{p.title}</h3>
                    <p>{p.description}</p>
                    <div className="tags">
                      {p.tags.map((t) => <span key={t}>#{t}</span>)}
                    </div>
                    <div className="links">
                      <a className="repo" href={p.repo} target="_blank" rel="noopener noreferrer">
                        <Icon name="github" className="ri" />
                        {repoName(p.repo)}
                      </a>
                      <span className="repo stars">
                        <Icon name="star" className="star" />
                        <CountUp to={p.stars} start={inView} />
                      </span>
                    </div>
                  </div>
                </>
              )}
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useEffect, useState } from "react";
import useInView from "../hooks/useInView";

/**
 * Fades/slides its content in when it scrolls into view.
 *
 *  <Reveal className="card" delay={0.1} draw>...</Reveal>
 *
 *  - delay: seconds to wait (for staggered lists)
 *  - draw:  also "draws" any <Icon> line icons inside, and replays on hover
 *  - as:    which HTML tag to render (default "div")
 *  - children can be a function: ({ inView }) => ...  (to start other animations)
 */
export default function Reveal({ as: Tag = "div", className = "", delay = 0, draw = false, style, children, onMouseEnter, ...rest }) {
  const [ref, inView] = useInView();
  const [drawn, setDrawn] = useState(false);

  // Start drawing icons shortly after the element appears
  useEffect(() => {
    if (!draw || !inView) return;
    const t = setTimeout(() => setDrawn(true), 250);
    return () => clearTimeout(t);
  }, [draw, inView]);

  const handleEnter = (e) => {
    onMouseEnter?.(e);
    if (draw && inView) {
      // Remove the class for one frame, then add it back → animation restarts
      setDrawn(false);
      requestAnimationFrame(() => requestAnimationFrame(() => setDrawn(true)));
    }
  };

  const classes = [className, "reveal", inView && "in", draw && "draw", drawn && "drawn"].filter(Boolean).join(" ");

  return (
    <Tag ref={ref} className={classes} style={{ "--d": `${delay}s`, ...style }} onMouseEnter={handleEnter} {...rest}>
      {typeof children === "function" ? children({ inView }) : children}
    </Tag>
  );
}

import { useEffect, useState } from "react";

/** Counts from 0 to `to` (with an ease-out) once `start` becomes true. */
export default function CountUp({ to, suffix = "", start, duration = 1400 }) {
  const [value, setValue] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!start) return;
    let raf;
    const t0 = performance.now();
    const tick = (t) => {
      const p = Math.min((t - t0) / duration, 1);
      setValue(Math.round(to * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
      else setDone(true);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [start, to, duration]);

  return (
    <>
      {value.toLocaleString()}
      {done ? suffix : ""}
    </>
  );
}

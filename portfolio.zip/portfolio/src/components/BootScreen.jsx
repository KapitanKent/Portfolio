import { useEffect, useState } from "react";
import { prefersReducedMotion } from "../hooks/useReducedMotion";

const LINES = [
  "> booting portfolio.exe",
  "> loading vectors .......... ok",
  "> compiling coffee ......... ok",
  "> ready.",
];

/** Short "terminal boot" intro. Click to skip. Calls onDone when finished. */
export default function BootScreen({ onDone }) {
  const [count, setCount] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (prefersReducedMotion()) { finish(); return; }
    if (count < LINES.length) {
      const t = setTimeout(() => setCount((c) => c + 1), 260);
      return () => clearTimeout(t);
    }
    const t = setTimeout(finish, 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [count]);

  function finish() {
    if (done) return;
    setDone(true);
    onDone();
  }

  return (
    <div id="boot" className={done ? "done" : ""} title="Click to skip" onClick={finish}>
      <pre>
        {LINES.slice(0, count).map((line) => (
          <div key={line}>
            {line.endsWith("ok") ? (
              <>
                {line.slice(0, -2)}
                <span className="ok">ok</span>
              </>
            ) : (
              line
            )}
          </div>
        ))}
        <span className="bar"><i /></span>
      </pre>
    </div>
  );
}

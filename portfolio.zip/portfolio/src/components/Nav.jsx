import { useEffect, useState } from "react";
import Icon from "./Icon";
import { profile, sections } from "../data";

/** Top nav + scroll progress bar + back-to-top button. */
export default function Nav() {
  const [progress, setProgress] = useState(0);
  const [small, setSmall] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [showTop, setShowTop] = useState(false);
  const [active, setActive] = useState("");

  // Scroll: progress, shrink, hide when scrolling down, show back-to-top
  useEffect(() => {
    let lastY = 0;
    const onScroll = () => {
      const y = scrollY;
      const max = document.documentElement.scrollHeight - innerHeight;
      setProgress(max > 0 ? (y / max) * 100 : 0);
      setSmall(y > 40);
      setHidden(y > lastY && y > 400);
      setShowTop(y > 600);
      lastY = y;
    };
    addEventListener("scroll", onScroll, { passive: true });
    return () => removeEventListener("scroll", onScroll);
  }, []);

  // Highlight the link of the section in the middle of the screen
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" }
    );
    document.querySelectorAll("section[id]").forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  return (
    <>
      <div id="progress" style={{ width: `${progress}%` }} />
      <nav id="nav" className={[small && "small", hidden && "hide"].filter(Boolean).join(" ")}>
        <a href="#home" className="logo">
          &lt;{profile.logo} <span>/&gt;</span>
          <i className="cur" />
        </a>
        <ul>
          {sections.map((s, i) => (
            <li key={s.id}>
              <a href={`#${s.id}`} className={active === s.id ? "active" : ""}>
                <b>{String(i + 1).padStart(2, "0")}.</b> {s.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
      <button id="toTop" className={showTop ? "show" : ""} aria-label="Back to top" onClick={() => scrollTo({ top: 0, behavior: "smooth" })}>
        <Icon name="arrowUp" />
      </button>
    </>
  );
}

import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import Icon from "./Icon";
import { hobbies } from "../data";

export default function Hobbies() {
  return (
    <section id="hobbies">
      <div className="container">
        <SectionHeader tag="02. when I'm not coding" title="Hobbies & Interests" />
        <div className="grid">
          {hobbies.map((h, i) => (
            <Reveal key={h.title} className="card hobby" delay={(i % 3) * 0.08} draw>
              <Icon name={h.icon} className="tile" as="div" />
              <h3>{h.title}</h3>
              <p>{h.text}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

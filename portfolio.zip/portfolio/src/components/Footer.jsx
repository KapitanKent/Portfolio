import { profile } from "../data";

export default function Footer() {
  return (
    <footer>
      Designed &amp; built by {profile.name} · © {new Date().getFullYear()} · made with{" "}
      <span className="heart">♥</span> and coffee
    </footer>
  );
}

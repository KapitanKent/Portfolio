import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import CountUp from "./CountUp";
import Icon from "./Icon";
import useInView from "../hooks/useInView";
import { languages, tools } from "../data";

export default function Languages() {
  const [chipsRef, chipsIn] = useInView();

  return (
    <section id="skills">
      <div className="container">
        <SectionHeader tag="03. tech stack" title="Programming Languages" />
        <div className="lang-grid">
          {languages.map((l, i) => (
            <Reveal key={l.name} className="card lang" delay={(i % 3) * 0.08} draw>
              {({ inView }) => (
                <>
                  <div className="hex">
                    <Icon name="hex" />
                    <b>{l.mono}</b>
                  </div>
                  <div className="info">
                    <div className="row">
                      <b>{l.name}</b>
                      <small>
                        {l.level} · <CountUp to={l.pct} suffix="%" start={inView} />
                      </small>
                    </div>
                    <div className="meter">
                      <div style={{ width: inView ? `${l.pct}%` : 0 }} />
                    </div>
                  </div>
                </>
              )}
            </Reveal>
          ))}
        </div>

        <div className="tools">
          <Reveal as="h3"><b>$</b> ls ./frameworks-and-tools</Reveal>
          <div className={`chips${chipsIn ? " in" : ""}`} ref={chipsRef}>
            {tools.map((t, i) => (
              <span className="chip" key={t} style={{ "--i": i }}>{t}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import CountUp from "./CountUp";
import Icon from "./Icon";
import RichText from "./RichText";
import { about } from "../data";

/** Builds the lines of the "about-me.js" code panel from data.js */
function codeLines(c) {
  const str = (v) => <span className="s">"{v}"</span>;
  return [
    <><span className="k">const</span> <span className="p">me</span> = {"{"}</>,
    <>  name: {str(c.name)},</>,
    <>  role: {str(c.role)},</>,
    <>  location: {str(c.location)},</>,
    <>  education: {str(c.education)},</>,
    <>  focus: [{c.focus.map((f, i) => <span key={f}>{i > 0 && ", "}{str(f)}</span>)}],</>,
    <>  learning: {str(c.learning)},</>,
    <>  funFact: {str(c.funFact)},</>,
    <>{"};"}</>,
    <> </>,
    <span className="c">// TODO: change the world</span>,
    <><span className="p">me</span>.build(); <span className="cursor" /></>,
  ];
}

export default function About() {
  return (
    <section id="about">
      <div className="container">
        <SectionHeader tag="01. whoami" title="About Me" />
        <div className="about">
          <div>
            {about.paragraphs.map((p, i) => (
              <Reveal as="p" key={i} delay={i * 0.08}>
                <RichText text={p} />
              </Reveal>
            ))}
            <div className="stats">
              {about.stats.map((s, i) => (
                <Reveal key={s.label} className="card stat" delay={i * 0.08} draw>
                  {({ inView }) => (
                    <>
                      <Icon name={s.icon} className="si" />
                      <b><CountUp to={s.value} suffix={s.suffix} start={inView} /></b>
                      <small>{s.label}</small>
                    </>
                  )}
                </Reveal>
              ))}
            </div>
          </div>

          <Reveal className="terminal" delay={0.1}>
            <div className="bar"><i /><i /><i /><span>about-me.js</span></div>
            <div className="code">
              {codeLines(about.code).map((line, i) => (
                <span className="ln" key={i} style={{ "--i": i }}>{line}</span>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

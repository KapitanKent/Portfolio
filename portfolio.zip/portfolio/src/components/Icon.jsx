import { Children, cloneElement, isValidElement } from "react";

/*
  Custom vector icon set (24×24 line icons).
  Usage:  <Icon name="mail" className="ci" />
  To add an icon, add a new key below with its SVG shapes.
  Shapes with class "fill" are filled instead of outlined.
*/
const ICONS = {
  gamepad: (
    <>
      <path d="M7 7h10a5 5 0 0 1 4.9 6l-.6 3a3 3 0 0 1-5.2 1.3L14.5 15h-5l-1.6 2.3a3 3 0 0 1-5.2-1.3l-.6-3A5 5 0 0 1 7 7z" />
      <path d="M7.5 10v4" />
      <path d="M5.5 12h4" />
      <circle cx="15.5" cy="11" r=".9" />
      <circle cx="17.8" cy="13" r=".9" />
    </>
  ),
  headphones: (
    <>
      <path d="M4 16v-4a8 8 0 0 1 16 0v4" />
      <path d="M4 15h2.5a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z" />
      <path d="M20 15h-2.5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1H19a1 1 0 0 0 1-1z" />
      <path d="M10 12.5v2" />
      <path d="M14 11.5v4" />
    </>
  ),
  camera: (
    <>
      <path d="M3 8.5a2 2 0 0 1 2-2h2.2L8.8 4h6.4l1.6 2.5H19a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <circle cx="12" cy="13" r="4" />
      <circle cx="12" cy="13" r="1.6" />
      <path d="M17.5 9.2h.01" />
    </>
  ),
  ball: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3v18" />
      <path d="M5.6 5.6c3.2 3.2 3.2 9.6 0 12.8" />
      <path d="M18.4 5.6c-3.2 3.2-3.2 9.6 0 12.8" />
    </>
  ),
  book: (
    <>
      <path d="M12 6.5C10 5 7 4.5 3.5 5v13c3.5-.5 6.5 0 8.5 1.5" />
      <path d="M12 6.5C14 5 17 4.5 20.5 5v13c-3.5-.5-6.5 0-8.5 1.5" />
      <path d="M12 6.5v13" />
      <path d="M6.5 9c1.3 0 2.5.3 3.5.8" />
      <path d="M14 9.8c1-.5 2.2-.8 3.5-.8" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3.5 9h17" />
      <path d="M3.5 15h17" />
      <path d="M12 3c2.6 2.5 3.8 5.6 3.8 9s-1.2 6.5-3.8 9" />
      <path d="M12 3C9.4 5.5 8.2 8.6 8.2 12s1.2 6.5 3.8 9" />
    </>
  ),
  briefcase: (
    <>
      <rect x="3" y="7" width="18" height="13" rx="2" />
      <path d="M8.5 7V5.5a1.5 1.5 0 0 1 1.5-1.5h4a1.5 1.5 0 0 1 1.5 1.5V7" />
      <path d="M3 12.5h18" />
      <path d="M11 12.5v2h2v-2" />
    </>
  ),
  layers: (
    <>
      <path d="M12 3 2.5 8 12 13l9.5-5z" />
      <path d="m2.5 12.5 9.5 5 9.5-5" />
      <path d="m2.5 16.5 9.5 5 9.5-5" />
    </>
  ),
  coffee: (
    <>
      <path d="M4 9h12v5.5A5.5 5.5 0 0 1 10.5 20h-1A5.5 5.5 0 0 1 4 14.5z" />
      <path d="M16 11h1.5a2.5 2.5 0 0 1 0 5H16" />
      <path d="M8 2.5c-.8 1 .8 2 0 3.5" />
      <path d="M12 2.5c-.8 1 .8 2 0 3.5" />
    </>
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m3.5 6.5 8.5 6.5 8.5-6.5" />
    </>
  ),
  linkedin: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="3" />
      <path d="M8 10.5V17" />
      <path d="M8 7.3v.01" />
      <path d="M12 17v-6.5" />
      <path d="M12 13.2a2.7 2.7 0 0 1 5 0V17" />
    </>
  ),
  github: (
    <path
      className="fill"
      d="M12 1.5a10.5 10.5 0 0 0-3.3 20.5c.5.1.7-.2.7-.5v-1.8c-2.9.6-3.5-1.4-3.5-1.4-.5-1.2-1.2-1.5-1.2-1.5-1-.7.1-.7.1-.7 1 .1 1.6 1.1 1.6 1.1.9 1.6 2.5 1.1 3.1.9.1-.7.4-1.1.7-1.4-2.3-.3-4.8-1.2-4.8-5.2 0-1.1.4-2.1 1.1-2.8-.1-.3-.5-1.3.1-2.8 0 0 .9-.3 2.9 1.1a10 10 0 0 1 5.3 0c2-1.4 2.9-1.1 2.9-1.1.6 1.5.2 2.5.1 2.8.7.7 1.1 1.7 1.1 2.8 0 4-2.5 4.9-4.8 5.2.4.3.7 1 .7 2v2.9c0 .3.2.6.7.5A10.5 10.5 0 0 0 12 1.5z"
    />
  ),
  gitlab: (
    <>
      <path d="M12 21 3.2 14.3a1 1 0 0 1-.4-1.1L5.5 4.6a.5.5 0 0 1 1 0L8.3 10h7.4l1.8-5.4a.5.5 0 0 1 1 0l2.7 8.6a1 1 0 0 1-.4 1.1z" />
      <path d="M8.3 10 12 21l3.7-11" />
    </>
  ),
  pin: (
    <>
      <path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z" />
      <circle cx="12" cy="9.5" r="2.6" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1" />
    </>
  ),
  star: <path className="fill" d="m12 2.5 2.9 6 6.6.8-4.9 4.6 1.3 6.6L12 17.2l-5.9 3.3 1.3-6.6-4.9-4.6 6.6-.8z" />,
  arrowRight: (
    <>
      <path d="M4 12h15" />
      <path d="m13 6 6 6-6 6" />
    </>
  ),
  arrowUp: (
    <>
      <path d="M12 20V5" />
      <path d="m6 11 6-6 6 6" />
    </>
  ),
  chat: (
    <>
      <path d="M4 5h16v11H9l-5 4z" />
      <path d="M8 9.5h8" />
      <path d="M8 12.5h5" />
    </>
  ),
  send: (
    <>
      <path d="M21 3 10 14" />
      <path d="m21 3-7 18-4-7-7-4z" />
    </>
  ),
  external: (
    <>
      <path d="M14 4h6v6" />
      <path d="M20 4 10 14" />
      <path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5" />
    </>
  ),
  copy: (
    <>
      <rect x="8" y="8" width="12" height="12" rx="2" />
      <path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3" />
    </>
  ),
  play: <path className="fill" d="M7 4.5v15a1 1 0 0 0 1.5.9l12-7.5a1 1 0 0 0 0-1.7l-12-7.6A1 1 0 0 0 7 4.5z" />,
  pause: (
    <>
      <rect className="fill" x="5" y="4" width="5" height="16" rx="1.2" />
      <rect className="fill" x="14" y="4" width="5" height="16" rx="1.2" />
    </>
  ),
  prev: (
    <>
      <path className="fill" d="M19 5.2v13.6a1 1 0 0 1-1.6.8L8.5 13a1 1 0 0 1 0-1.6l8.9-6.6a1 1 0 0 1 1.6.4z" />
      <rect className="fill" x="4.5" y="5" width="2.5" height="14" rx="1" />
    </>
  ),
  next: (
    <>
      <path className="fill" d="M5 5.2v13.6a1 1 0 0 0 1.6.8l8.9-6.6a1 1 0 0 0 0-1.6L6.6 4.8A1 1 0 0 0 5 5.2z" />
      <rect className="fill" x="17" y="5" width="2.5" height="14" rx="1" />
    </>
  ),
  vinyl: (
    <>
      <circle cx="12" cy="12" r="11" />
      <circle cx="12" cy="12" r="8" />
      <circle cx="12" cy="12" r="5.2" />
      <circle cx="12" cy="12" r="1.5" />
    </>
  ),
  hex: <polygon className="bgp" points="12 1.5 21.1 6.75 21.1 17.25 12 22.5 2.9 17.25 2.9 6.75" />,
};

/* Adds pathLength="1" to every shape so the CSS "draw" animation works. */
const SHAPES = ["path", "circle", "rect", "polygon", "line"];
function withPathLength(node) {
  return Children.map(node, (child) => {
    if (!isValidElement(child)) return child;
    if (SHAPES.includes(child.type)) return cloneElement(child, { pathLength: 1 });
    // Fragments (<>...</>) — process their children
    return cloneElement(child, {}, withPathLength(child.props.children));
  });
}

export const ICON_NAMES = Object.keys(ICONS);

export default function Icon({ name, className = "", as: Tag = "span" }) {
  const shapes = ICONS[name];
  if (!shapes) {
    console.warn(`Icon "${name}" not found. Available: ${ICON_NAMES.join(", ")}`);
    return null;
  }
  return (
    <Tag className={className} data-icon={name} aria-hidden="true">
      <svg className="svg-ico" viewBox="0 0 24 24">
        {withPathLength(shapes)}
      </svg>
    </Tag>
  );
}

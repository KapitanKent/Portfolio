/**
 * Renders text where <b>...</b> becomes bold — without using innerHTML,
 * so no HTML from data can ever be injected into the page.
 */
export default function RichText({ text }) {
  return text.split(/(<b>.*?<\/b>)/g).map((part, i) =>
    part.startsWith("<b>") ? <b key={i}>{part.slice(3, -4)}</b> : part
  );
}

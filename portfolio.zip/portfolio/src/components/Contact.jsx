import { useState } from "react";
import Reveal from "./Reveal";
import SectionHeader from "./SectionHeader";
import Icon from "./Icon";
import { contact, profile } from "../data";

/*
  NOTE: the form is a mockup — it doesn't send anything.
  To make it work, connect it to a form service or your own API
  (and validate/sanitize input on the server side).
*/
export default function Contact({ toast }) {
  const [shake, setShake] = useState(false);
  const [fly, setFly] = useState(false);

  const copyEmail = (e) => {
    if (!navigator.clipboard) return; // falls back to opening the mail app
    e.preventDefault();
    navigator.clipboard.writeText(contact.email).then(() => toast("✔ Email copied to clipboard"));
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (!form.checkValidity()) {
      setShake(false);
      requestAnimationFrame(() => setShake(true));
      toast("Please fill in all fields with a valid email.");
      return;
    }
    setFly(true);
    setTimeout(() => setFly(false), 1200);
    toast("✔ Message sent! (mockup only — not connected to a backend)");
    form.reset();
  };

  const items = [
    { icon: "mail", label: "email · click to copy", value: contact.email, href: `mailto:${contact.email}`, onClick: copyEmail, go: "copy" },
    ...contact.links.map((l) => ({ ...l, external: true, go: "external" })),
    { icon: "pin", label: "location", value: profile.location },
  ];

  return (
    <section id="contact">
      <div className="container">
        <SectionHeader tag="06. let's connect" title="Contact Me" />
        <div className="contact">
          <div className="contact-list">
            <Reveal as="p" className="contact-intro">{contact.intro}</Reveal>
            {items.map((it, i) => {
              const inner = (
                <>
                  <Icon name={it.icon} className="ci" />
                  <div><small>{it.label}</small>{it.value}</div>
                  {it.go && <Icon name={it.go} className="go" />}
                </>
              );
              return it.href ? (
                <Reveal
                  as="a" key={it.label} className="card contact-item" delay={i * 0.06} draw
                  href={it.href} onClick={it.onClick}
                  {...(it.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                >
                  {inner}
                </Reveal>
              ) : (
                <Reveal key={it.label} className="card contact-item" delay={i * 0.06} draw>{inner}</Reveal>
              );
            })}
          </div>

          <Reveal as="form" className={`card contact-form${shake ? " shake" : ""}`} onSubmit={onSubmit} noValidate>
            <div className="field">
              <input id="fName" name="name" type="text" placeholder=" " required maxLength={100} />
              <label htmlFor="fName">name</label>
            </div>
            <div className="field">
              <input id="fEmail" name="email" type="email" placeholder=" " required maxLength={200} />
              <label htmlFor="fEmail">email</label>
            </div>
            <div className="field">
              <textarea id="fMsg" name="message" placeholder=" " required maxLength={2000} />
              <label htmlFor="fMsg">message</label>
            </div>
            <button type="submit" className={`btn primary send magnetic${fly ? " fly" : ""}`}>
              Send message <Icon name="send" className="bi" />
            </button>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

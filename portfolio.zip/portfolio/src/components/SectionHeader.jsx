import { useEffect, useState } from "react";
import Reveal from "./Reveal";
import useInView from "../hooks/useInView";
import { prefersReducedMotion } from "../hooks/useReducedMotion";

const GLYPHS = "!<>-_\\/[]{}=+*^?#01";

/** Heading that "decodes" from random symbols into the real text. */
function ScrambleText({ text }) {
  const [ref, inView] = useInView();
  const [shown, setShown] = useState(text);

  useEffect(() => {
    if (!inView || prefersReducedMotion()) return;
    let raf;
    const t0 = performance.now();
    const dur = 900;
    const tick = (t) => {
      const p = Math.min((t - t0) / dur, 1);
      const done = Math.floor(p * text.length);
      let out = text.slice(0, done);
      for (let k = done; k < text.length; k++) {
        out += text[k] === " " ? " " : GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
      }
      setShown(out);
      if (p < 1) raf = requestAnimationFrame(tick);
      else setShown(text);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, text]);

  return <span ref={ref}>{shown}</span>;
}

/** "01. whoami" tag + big section title */
export default function SectionHeader({ tag, title }) {
  return (
    <>
      <Reveal className="section-tag">{tag}</Reveal>
      <Reveal as="h2">
        <ScrambleText text={title} />
      </Reveal>
    </>
  );
}

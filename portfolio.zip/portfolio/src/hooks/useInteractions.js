import { useEffect } from "react";
import { prefersReducedMotion, hasFinePointer } from "./useReducedMotion";

/**
 * Page-wide mouse effects, handled with one listener each (event delegation):
 *  - .card       → glow + border light follow the cursor (sets --mx / --my)
 *  - .tilt       → 3D tilt toward the cursor
 *  - .magnetic   → element is pulled slightly toward the cursor
 *  - .btn        → ripple on click
 */
export default function useInteractions() {
  useEffect(() => {
    const reduce = prefersReducedMotion();
    const fine = hasFinePointer();
    let lastTilt = null, lastMag = null;

    const onMove = (e) => {
      const card = e.target.closest?.(".card");
      if (card) {
        const b = card.getBoundingClientRect();
        card.style.setProperty("--mx", `${e.clientX - b.left}px`);
        card.style.setProperty("--my", `${e.clientY - b.top}px`);
      }
      if (reduce) return;

      const tilt = e.target.closest?.(".tilt");
      if (lastTilt && lastTilt !== tilt) lastTilt.style.transform = "";
      if (tilt) {
        const b = tilt.getBoundingClientRect();
        const x = (e.clientX - b.left) / b.width - 0.5;
        const y = (e.clientY - b.top) / b.height - 0.5;
        tilt.style.transform = `translateY(-6px) rotateY(${x * 9}deg) rotateX(${-y * 9}deg)`;
      }
      lastTilt = tilt;

      if (!fine) return;
      const mag = e.target.closest?.(".magnetic");
      if (lastMag && lastMag !== mag) lastMag.style.transform = "";
      if (mag) {
        const b = mag.getBoundingClientRect();
        mag.style.transform = `translate(${(e.clientX - b.left - b.width / 2) * 0.25}px, ${(e.clientY - b.top - b.height / 2) * 0.35}px)`;
      }
      lastMag = mag;
    };

    const onClick = (e) => {
      const btn = e.target.closest?.(".btn");
      if (!btn) return;
      const r = btn.getBoundingClientRect();
      const s = Math.max(r.width, r.height);
      const rp = document.createElement("span");
      rp.className = "ripple";
      rp.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
      btn.appendChild(rp);
      setTimeout(() => rp.remove(), 650);
    };

    document.addEventListener("mousemove", onMove);
    document.addEventListener("click", onClick);
    return () => {
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("click", onClick);
    };
  }, []);
}

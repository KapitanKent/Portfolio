/*
  ============================================================
  ALL PORTFOLIO CONTENT LIVES HERE.
  Edit this file to put in your real details — you usually
  don't need to touch the components at all.
  Icon names must match a key in src/components/Icon.jsx.
  ============================================================
*/

export const profile = {
  name: "Kent Dominic L. Abadiano",
  logo: "KD",
  roles: ["Software Engineer", "Full-Stack Developer", "Problem Solver", "Lifelong Learner"],
  intro:
    "I enjoy solving problems with code, from designing backend services to polishing web apps people like using. I care about reliability, scalability, and the details that make software feel good.",
  location: "Cebu City, Philippines",
  openToWork: true,
  // Put your photo in the /public folder (e.g. public/me.jpg) and set: photo: "/me.jpg"
  photo: null,
};

export const about = {
  paragraphs: [
  "Hi! I'm <b>Kent Dominic L. Abadiano</b>, a software engineer with <b>4 years</b> of experience building web applications, APIs, and internal tools. I like taking messy problems and turning them into reliable software that people actually use.",
  "My journey started with a summer job in <b>IT Support at Big Blue Logistics</b>, where I learned how technology keeps a business running day to day. I then joined <b>NEC Telecom Software Phils. Inc.</b> as an <b>intern</b>, which was my first hands-on experience with professional software development.",
  "Outside of work, I enjoy living life at my own pace, and a lot of that includes learning new frameworks, experimenting with new tools, and building things just for the fun of it."
],
  stats: [
    { icon: "briefcase", value: 2, suffix: "+", label: "Years experience" },
    { icon: "layers", value: 14, suffix: "+", label: "Projects shipped" },
    { icon: "coffee", value: 2500, suffix: "+", label: "Cups of coffee" },
  ],
  // Shown in the animated code panel
  code: {
    name: "Kent Dominic L. Abadiano",
    role: "Software Engineer",
    location: "Cebu City, Philippines",
    education: "BS Information Technology",
    focus: ["Backend", "Frontend", "Web Apps"],
    learning: "Game Developing",
    funFact: "Debugs best at 2 AM",
  },
};

export const hobbies = [
  { icon: "gamepad", title: "Gaming", text: "Strategy and co-op games with friends. Great for problem-solving and teamwork." },
  { icon: "headphones", title: "Music", text: "Always have a playlist on while coding. Check out my favorites below." },
  { icon: "camera", title: "Photography", text: "Capturing street scenes and landscapes on weekend walks." },
  { icon: "ball", title: "Basketball", text: "Weekend pickup games to stay active and clear my head." },
  { icon: "book", title: "Reading", text: "Tech books, sci-fi novels, and the occasional productivity guide." },
  { icon: "globe", title: "Traveling", text: "Exploring new places, food, and cultures whenever I can." },
];

export const languages = [
  { mono: "JS", name: "JavaScript", level: "Advanced", pct: 80 },
  { mono: "TS", name: "TypeScript", level: "Advanced", pct: 85 },
  { mono: "Py", name: "Python", level: "Intermediate", pct: 65 },
  { mono: "Jv", name: "Java", level: "Intermediate", pct: 70 },
  { mono: "C", name: "C", level: "Average", pct: 50 },
  { mono: "SQL", name: "SQL", level: "Advanced", pct: 80 },
];

export const tools = [
  "React", "Node.js", "Express", "Spring Boot", ".NET", "PostgreSQL",
  "MySQL", "Docker", "Git", "GitLab CI/CD", "Linux", "REST APIs",
];

export const projects = [
  {
    title: "TaskFlow",
    description: "A Kanban-style task manager with real-time updates, drag-and-drop boards, and team workspaces.",
    tags: ["React", "Node.js", "PostgreSQL"],
    repo: "https://github.com/your-username/taskflow",
    stars: 128,
    // Put a screenshot in /public and set e.g. image: "/taskflow.png"
    image: null,
  },
  {
    title: "WeatherNow API",
    description: "A REST API that aggregates weather data from multiple providers with caching and rate limiting.",
    tags: ["Python", "FastAPI", "Redis", "Docker"],
    repo: "https://github.com/your-username/weathernow-api",
    stars: 64,
    image: null,
  },
  {
    title: "ShopLite",
    description: "A lightweight e-commerce site with product search, cart, checkout flow, and an admin dashboard.",
    tags: ["Java", "Spring Boot", "MySQL"],
    repo: "https://github.com/your-username/shoplite",
    stars: 42,
    image: null,
  },
];

export const playlist = {
  name: "Code Mode",
  url: "https://open.spotify.com/playlist/YOUR_PLAYLIST_ID",
  tracks: [
    { title: "Song Title One", artist: "Artist Name", seconds: 221 },
    { title: "Song Title Two", artist: "Artist Name", seconds: 245 },
    { title: "Song Title Three", artist: "Artist Name", seconds: 198 },
    { title: "Song Title Four", artist: "Artist Name", seconds: 177 },
    { title: "Song Title Five", artist: "Artist Name", seconds: 213 },
    { title: "Song Title Six", artist: "Artist Name", seconds: 252 },
  ],
};

export const contact = {
  intro: "Have a project, opportunity, or just want to say hi? My inbox is always open.",
  email: "you@example.com",
  links: [
    { icon: "linkedin", label: "linkedin", value: "linkedin.com/in/your-username", href: "https://www.linkedin.com/in/your-username" },
    { icon: "github", label: "github", value: "github.com/your-username", href: "https://github.com/your-username" },
    { icon: "gitlab", label: "gitlab", value: "gitlab.com/your-username", href: "https://gitlab.com/your-username" },
  ],
};

// Section order + labels used by the nav bar
export const sections = [
  { id: "about", label: "about" },
  { id: "hobbies", label: "hobbies" },
  { id: "skills", label: "languages" },
  { id: "projects", label: "projects" },
  { id: "playlist", label: "playlist" },
  { id: "contact", label: "contact" },
];

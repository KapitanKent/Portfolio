import { useEffect, useState } from "react";
import Background from "./components/Background";
import BootScreen from "./components/BootScreen";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import About from "./components/About";
import Hobbies from "./components/Hobbies";
import Languages from "./components/Languages";
import Projects from "./components/Projects";
import Playlist from "./components/Playlist";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import { useToast } from "./components/Toast";
import useInteractions from "./hooks/useInteractions";

export default function App() {
  const [ready, setReady] = useState(false);
  const [toast, toastElement] = useToast();
  useInteractions();

  // The hero intro animations start when <body> gets the "ready" class
  useEffect(() => {
    document.body.classList.toggle("loading", !ready);
    document.body.classList.toggle("ready", ready);
  }, [ready]);

  return (
    <>
      <Background />
      <BootScreen onDone={() => setReady(true)} />
      <Nav />
      <main>
        <Hero />
        <About />
        <Hobbies />
        <Languages />
        <Projects />
        <Playlist />
        <Contact toast={toast} />
      </main>
      <Footer />
      {toastElement}
    </>
  );
}
